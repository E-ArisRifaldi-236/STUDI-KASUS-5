#include "mahasiswa.h"

int main()
{
  ProjectMahasiswa base;
  base.input();
  base.proses();
  base.output();
  return 0;
}